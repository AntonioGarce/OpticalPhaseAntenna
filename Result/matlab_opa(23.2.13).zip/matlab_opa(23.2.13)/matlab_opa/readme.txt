##par means parallel processing

opa: olg grouping algorithm 
par_old_origin: parallel + old grouping algorithm
par_old_update0: parallel + olg grouping algorithm + updated fitness function
par_old_update1: parallel + old grouping algorithm + updated fitness function + iteration with weight updating
par_newgrouping_stage5_origin: new grouping algorithm + updated function in stage 5 without iteration.
par_newgrouping_stage5_update: new grouping algorithm + updated function in stage 5 with iterations.
par_newgrouping_stage6: new grouping algorithm in stage 6

opa_ga: ga for full range for one steer
opa_pso: pso for full range for one steer

par_optga_steer: ga for beam steering with group phases(2.14)
par_optpso_steer: pso for beam steering with group phases(2.14)
