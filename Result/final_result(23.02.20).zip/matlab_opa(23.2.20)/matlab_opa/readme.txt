par_old_origin: old grouping + psll
par_old_update0: old grouping + fitness function(psll+w*maxpeak)
par_old_update1: old grouping + fitness function(psll+w*maxpeak) + iteration of w
par_optga_steer: ga 
par_optpso_steer: pso
par_newgrouping_stage5_origin: new grouping + fitness function(psll+w*maxpeak)
par_newgrouping_stage5_update: new grouping + fitness function(psll+w*maxpeak) + iteration of w