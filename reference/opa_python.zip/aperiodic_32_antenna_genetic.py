# -*- coding: utf-8 -*-
"""
Created on Wed May 19 16:10:08 2021

@author: Hsuan

#20210519
#Steering angle =0pi
#find the maximum PSLL aperiodic OPA
#iteration: 150
#view angle :-60°~60°

#condition setting:
# 1.side lobe beside main lobe not exceed 0.025
# 2.max side lobe < 0.18
"""

#------------------------------------------------------------------------------
import numpy as np
import math
import cmath
import random
import matplotlib.pyplot as plt 
import time

start = time.process_time()

#------------------------------------------------------------------------------
# This project is extended and a library called PyGAD is released to build the genetic algorithm.
# PyGAD documentation: https://pygad.readthedocs.io
# Install PyGAD: pip install pygad
# PyGAD source code at GitHub: https://github.com/ahmedfgad/GeneticAlgorithmPython

def cal_pop_fitness(equation_inputs, pop):
    # Calculating the fitness value of each solution in the current population.
    # The fitness function caulcuates the sum of products between each input and its corresponding weight.
    '''
    param equation_inputs: input value
    param pop: population matrix
    '''
    #fitness = np.sum(pop*equation_inputs, axis=1)  #axis represent :add the number of subgroups in each dimension array in the matrix
    #--------------------------------------------------------------------------
    
    N = 32   #number of channel (N)
    d = 4.4  #pitch of  each antenna
    l = 1.55 #lambda
    beta = (2*np.pi/l)
    p=  np.arange (-60.0, 60.01, 0.01)

    phase_angle = 0
    
    
    

    C = [[0] * N for row in range(R)]

    for j in range(R):
        for k in range(N):
            C[j][k] = equation_inputs[j][k] * pop[j][k] #C matrix is the result of mutiple of input matric and weight matrix        
    

    I = np.arange(N)
    I = np.tile(I, (R, 1))
  
    #--------------------------------------------------------------------------
    SumRe2 = 0.0
    SumIm2 = 0.0
    fitness = 0
   
    arr = [None] * R
    for m in range (R):
        SumRe2 = 0.0
        SumIm2 = 0.0
        fitness = 0
        dd = 0
        for n in range(N):
            dd = dd + C[m][n]
            phase2 = beta * dd * (np.sin(p*np.pi/180))    #origianl + pitch+ random pitch

#       print(k+1, "=", C[m][n])

            phaseRe2 = np.cos(phase2)
            phaseIm2 = np.sin(phase2)
            SumRe2 += phaseRe2
            SumIm2 += phaseIm2


    
        intensity2 = (SumRe2/N)**2 + (SumIm2/N)**2    
        #print(intensity2)
        
        max_inten = 0
        for j in range(4500):
            if intensity2[j] > max_inten:
                max_inten = intensity2[j]
                
        max_inten_right = 0
        for k in range(4500, 5940):
            if intensity2[k] > max_inten_right:
                max_inten_right = intensity2[k]
                
        #max_inten_mid = 0
        #for l in range(61000, 75000):
        #    if intensity2[l] > max_inten_mid:
        #        max_inten_mid = intensity2[l]
        #print('Max =', max_inten)
        
        
        for q in range(len(intensity2)):
            fitness += intensity2[q]
        #print('fitness =', fitness)
        
        if max_inten > 0.116:
            fitness = fitness + 20000
        
        if max_inten_right > 0.02165:
            fitness = fitness + 20000
            
        #if max_inten_mid < 0.67:
        #    fitness = fitness + 20000
        
        #print('fitness2 =', fitness)
        
        arr[m] = fitness
   
    fitness = arr        
    
    return fitness

#------------------------------------------------------------------------------

def select_mating_pool(pop, fitness, num_parents):
    # Selecting the best individuals in the current generation as parents for producing the offspring of the next generation.
    '''
    select the best parent
    param pop:  population matrix
    param fitness: the fitness result of the individual
    param num_parents:  the number of the parent which have to be maintained
    '''
    max_fitness_idx = [[0,0]] 
    parents = np.empty((num_parents, pop.shape[1]))  #c.shape = (4,2), c.shape[0] = 4, c.shape[1] = 2
    for parent_num in range(num_parents):
        max_fitness_idx = np.where(fitness == np.min(fitness))
        #print('max_fitness_idx =', max_fitness_idx)
        max_fitness_idx = max_fitness_idx[0][0]
        #print('max_fitness_idx 11 =', max_fitness_idx)
        parents[parent_num, :] = pop[max_fitness_idx, :]
        fitness[max_fitness_idx] = 99999999999
        #print(max_fitness_idx)
    #print(parents)
    return parents

def crossover(parents, offspring_size):
    '''
    Crossover
    param parents: the matric of parent
    param offspring_size: the number of offspring
    '''
    offspring = np.empty(offspring_size)
    # The point at which crossover takes place between two parents. Usually it is at the center.
    crossover_point = np.uint8(offspring_size[1]/4)  #16 / 4 = 4

    for k in range(offspring_size[0]):
        # Index of the first parent to mate.
        parent1_idx = k%parents.shape[0]
        # Index of the second parent to mate.
        parent2_idx = (k+1)%parents.shape[0]
        # The new offspring will have its first half of its genes taken from the first parent.
        offspring[k, 0:crossover_point] = parents[parent1_idx, 0:crossover_point]
        # The new offspring will have its second half of its genes taken from the second parent.
        offspring[k, crossover_point:] = parents[parent2_idx, crossover_point:]
        #print(offspring)
    return offspring

def mutation(offspring_crossover):
    # Mutation changes a single gene in each offspring randomly.
    '''
    Mutation
    param offspring_crossover: the number of offspring after mutation
    param num_mutations: The number of mutated features
    '''
    for idx in range(offspring_crossover.shape[0]):
        # The random value to be added to the gene.
        random_value = np.random.uniform(0.8, 1.2, 1)
        random_value1 = np.random.uniform(0.8, 1.2, 1)
        random_value2 = np.random.uniform(0.8, 1.2, 1)
        random_value3 = np.random.uniform(0.8, 1.2, 1)
        ran = random.randint(1, 10)
        if ran > 3:
            offspring_crossover[idx, 1] = offspring_crossover[idx, 1] * random_value3
        if ran > 2:
            offspring_crossover[idx, 3] = offspring_crossover[idx, 3] * random_value
        if ran > 5:
            offspring_crossover[idx, 5] = offspring_crossover[idx, 5] * random_value3    
        if ran > 4:
            offspring_crossover[idx, 7] = offspring_crossover[idx, 7] * random_value1
        if ran > 2:
            offspring_crossover[idx, 9] = offspring_crossover[idx, 9] * random_value2
        if ran > 4:
            offspring_crossover[idx, 11] = offspring_crossover[idx, 11] * random_value1
        if ran > 2:
            offspring_crossover[idx, 13] = offspring_crossover[idx, 13] * random_value3
        if ran > 3:
            offspring_crossover[idx, 15] = offspring_crossover[idx, 2] * random_value
        if ran > 3:
            offspring_crossover[idx, 18] = offspring_crossover[idx, 18] * random_value2
        if ran > 3:
            offspring_crossover[idx, 19] = offspring_crossover[idx, 19] * random_value
        if ran > 2:
            offspring_crossover[idx, 21] = offspring_crossover[idx, 21] * random_value3        
        if ran > 4:
            offspring_crossover[idx, 23] = offspring_crossover[idx, 23] * random_value1
        if ran > 2:
            offspring_crossover[idx, 26] = offspring_crossover[idx, 26] * random_value2
        if ran > 3:
            offspring_crossover[idx, 27] = offspring_crossover[idx, 27] * random_value1
        if ran > 5:
            offspring_crossover[idx, 29] = offspring_crossover[idx, 29] * random_value3
        if ran > 2:
            offspring_crossover[idx, 31] = offspring_crossover[idx, 31] * random_value
        
        
        
        
    return offspring_crossover


#------------------------------------------------------------------------------
R = 32
N = 32  #number of channel (N)
d = 4.4  #pitch of  each antenna
l = 1.55 #lambda
beta = (2*np.pi/l)
p = np.arange (-60.0, 60.001, 0.001)
phase_angle = 0

sol_per_pop = R   #in the individual  generate R solution randomly

# Inputs of the equation.
equation_inputs = np.zeros((sol_per_pop, N))
for i in range(R):
    equation_inputs[i] = np.array([d]*N)


# Number of the weights we are looking to optimize.
num_weights = N

"""
Genetic algorithm parameters:
    Mating pool size
    Population size
"""

num_parents_mating = 16

# Defining the population size. shape(8, 16)
pop_size = (sol_per_pop, num_weights) # The population will have sol_per_pop chromosome where each chromosome has num_weights genes.
#Creating the initial population.
new_population1 = np.random.uniform(low=0.6, high=1.4, size = (R, N))
                        


new_population = np.vstack((fir4, fir2, fir3, new_population1, fir1))

 
print(new_population)


num_generations = 150
for generation in range(num_generations):
    print("Generation : ", generation+1)
    # Measing the fitness of each chromosome in the population.
    fitness = cal_pop_fitness(equation_inputs, new_population)
    print(fitness)
    

    # Selecting the best parents in the population for mating.
    parents = select_mating_pool(new_population, fitness, 
                                      num_parents_mating)

    # Generating next generation using crossover.
    offspring_crossover = crossover(parents,
                                       offspring_size=(pop_size[0]-parents.shape[0], num_weights)) #offspring_size = 8-4=4

    # Adding some variations to the offsrping using mutation.
    offspring_mutation = mutation(offspring_crossover)

    # Creating the new population based on the parents and offspring.
    new_population[0:parents.shape[0], :] = parents
    new_population[parents.shape[0]:, :] = offspring_mutation

    # The best result in the current iteration.
    print("Best result : ", np.min(np.sum(new_population*equation_inputs, axis=1)))

# Getting the best solution after iterating finishing all generations.
#At first, the fitness is calculated for each solution in the final generation.
fitness = cal_pop_fitness(equation_inputs, new_population)
# Then return the index of that solution corresponding to the best fitness.
best_match_idx = np.where(fitness == np.min(fitness))

print("Best solution : ", new_population[best_match_idx, :])
#print("Best solution fitness : ", fitness[best_match_idx])


end = time.process_time()
print("excution time：%f sec" % (end - start))

