# -*- coding: utf-8 -*-
"""
Created on Tue Jun  1 16:33:04 2021

@author: Hsuan
"""

import numpy as np
import math
import cmath
import random
import matplotlib.pyplot as plt 
import time

#------------------------------------------------------------------------------
N = 64   #number of channel (N)
d = 9.5  #pitch of  each antenna
l = 1.55 #lambda
beta = (2*np.pi/l)
p = np.arange (-5.0, 5.001, 0.001)
phase_angle = 0

rd_phase = [None]*N
rd_phaseError = [None]*N

start = time.process_time()


phase = phase = np.random.uniform(0, 2*np.pi, 64) #generate 64 initial phase error

#------------------------------------------------------------------------------

loop_32 = 1

while loop_32 == 1:
    tuning_phase_32 = random.uniform(-180.0, 180.0)
    SumRe1 = 0.0
    SumIm1 = 0.0
    SumRe2 = 0.0
    SumIm2 = 0.0  
    
    
    for i in range (0, 32):
        phase1 = i * beta * d * np.sin(p*np.pi/180) + phase[i] * np.pi/180 + (0) * np.pi/180     #original + ransom phase #+ rd_phase[i+1]*np.pi/180
        
        #print(rd_phase[i+1])
        phaseRe1 = np.cos(phase1)
        phaseIm1 = np.sin(phase1)
        SumRe1 += phaseRe1
        SumIm1 += phaseIm1
    
    for j in range (32, N):
        phase2 =  j * beta * d * np.sin(p*np.pi/180) + phase[j] * np.pi/180 + (0) * np.pi/180
        #phase2 =  j * beta * d * np.sin(p*np.pi/180) + phase[j] * np.pi/180 + tuning[l] * np.pi/180
        
        phaseRe2 = np.cos(phase2)
        phaseIm2 = np.sin(phase2)
        SumRe2 += phaseRe2
        SumIm2 += phaseIm2
        
        
    intensity1 = np.sqrt(abs(((SumRe1+SumRe2)/N)**2 + ((SumIm1+SumIm2)/N)**2))
    
    max_inten_32_left = 0
    max_inten_32_right = 0
    
    for k in range(2200):
        if intensity1[k] > max_inten_32_left:
            max_inten_32_left = intensity1[k]
    
    
    for l in range(2800, 5001):
        if intensity1[l] > max_inten_32_right:
            max_inten_32_right = intensity1[l]
        
        if max_inten_32_left < 0.20 and max_inten_32_right < 0.20:
            loop_32 = 0
            #continue
           
print("tunung_phase: ", tuning_phase_32, "max_left: ", max_inten_32_left, "max_right: ", max_inten_32_right)

plt.figure(figsize = (18, 12))


plt.ylim([0, 1])    # boundary of y axis
plt.yticks([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])  # set y scale
plt.plot(p, intensity1)
plt.title('Phase0 = 0 deg')
plt.xlabel('phase dimension (degree)')
plt.ylabel('intensity')
plt.grid(True)
plt.show()



loop_16 = 1

while loop_16 == 1:
    tuning_phase_16 = random.uniform(-180.0, 180.0)
SumRe1 = 0.0
SumIm1 = 0.0
SumRe2 = 0.0
SumIm2 = 0.0
SumRe3 = 0.0
SumIm3 = 0.0
SumRe4 = 0.0
SumIm4 = 0.0
SumRe5 = 0.0
SumIm5 = 0.0
SumRe6 = 0.0
SumIm6 = 0.0
SumRe7 = 0.0
SumIm7 = 0.0
SumRe8 = 0.0
SumIm8 = 0.0
SumRe9 = 0.0
SumIm9 = 0.0
SumRe10 = 0.0
SumIm10 = 0.0
SumRe11 = 0.0
SumIm11 = 0.0
SumRe12 = 0.0
SumIm12 = 0.0
SumRe13 = 0.0
SumIm13 = 0.0
SumRe14 = 0.0
SumIm14 = 0.0
SumRe15 = 0.0
SumIm15 = 0.0
SumRe16 = 0.0
SumIm16 = 0.0
SumRe17 = 0.0
SumIm17 = 0.0
SumRe18 = 0.0
SumIm18 = 0.0
SumRe19 = 0.0
SumIm19 = 0.0
SumRe20 = 0.0
SumIm20 = 0.0
SumRe21 = 0.0
SumIm21 = 0.0
SumRe22 = 0.0
SumIm22 = 0.0
SumRe23 = 0.0
SumIm23 = 0.0
SumRe24 = 0.0
SumIm24 = 0.0
SumRe25 = 0.0
SumIm25 = 0.0
SumRe26 = 0.0
SumIm26 = 0.0
SumRe27 = 0.0
SumIm27 = 0.0
SumRe28 = 0.0
SumIm28 = 0.0
SumRe29 = 0.0
SumIm29 = 0.0
SumRe30 = 0.0
SumIm30 = 0.0
SumRe31 = 0.0
SumIm31 = 0.0
SumRe32 = 0.0
SumIm32 = 0.0


a_32 = 46.65
b_32 =  3.22


a_16 =  random.uniform(0, 360)
b_16 =  random.uniform(0, 360)
c_16 =  random.uniform(0, 360)
d_16 =  random.uniform(0, 360)


a_8 =  random.uniform(0, 360)
b_8 =  random.uniform(0, 360)
c_8 =  random.uniform(0, 360)
d_8 =  random.uniform(0, 360)
e_8 =  random.uniform(0, 360)
f_8 =  random.uniform(0, 360)
g_8 =  random.uniform(0, 360)
h_8 =  random.uniform(0, 360)

a_4 =  random.uniform(0, 360)
b_4 =  random.uniform(0, 360)
c_4 =  random.uniform(0, 360)
d_4 =  random.uniform(0, 360)
e_4 =  random.uniform(0, 360)
f_4 =  random.uniform(0, 360)
g_4 =  random.uniform(0, 360)
h_4 =  random.uniform(0, 360)

i_4 =  random.uniform(0, 360)
j_4 =  random.uniform(0, 360)
k_4 =  random.uniform(0, 360)
l_4 =  random.uniform(0, 360)
m_4 =  random.uniform(0, 360)
n_4 =  random.uniform(0, 360)
o_4 =  random.uniform(0, 360)
p_4 =  random.uniform(0, 360)

#group 5 better result
a_2 = random.uniform(0, 360)
b_2 = random.uniform(0, 360)
c_2 = random.uniform(0, 360)
d_2 = random.uniform(0, 360)
e_2 = random.uniform(0, 360)
f_2 = random.uniform(0, 360)
g_2 = random.uniform(0, 360)
h_2 = random.uniform(0, 360)
i_2 = random.uniform(0, 360)
j_2 = random.uniform(0, 360)
k_2 = random.uniform(0, 360)
l_2 = random.uniform(0, 360)
m_2 = random.uniform(0, 360)
n_2 = random.uniform(0, 360)
o_2 = random.uniform(0, 360)
p_2 = random.uniform(0, 360)

q_2 = random.uniform(0, 360)
r_2 = random.uniform(0, 360)
s_2 = random.uniform(0, 360)
t_2 = random.uniform(0, 360)
u_2 = random.uniform(0, 360)
v_2 = random.uniform(0, 360)
w_2 = random.uniform(0, 360)
x_2 = random.uniform(0, 360)
y_2 = random.uniform(0, 360)
z_2 = random.uniform(0, 360)
aa_2 = random.uniform(0, 360)
ab_2 = random.uniform(0, 360)
ac_2 = random.uniform(0, 360)
ad_2 = random.uniform(0, 360)
ae_2 = random.uniform(0, 360)
af_2 = random.uniform(0, 360)


for i in range(0, 2):
    phase1 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (a_8) * np.pi/180 + (a_4) * np.pi/180 + (a_2) * np.pi/180
    phaseRe1 = np.cos(phase1)
    phaseIm1 = np.sin(phase1)
    SumRe1 += phaseRe1
    SumIm1 += phaseIm1

for i in range(2, 4):
    phase17 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (a_8) * np.pi/180 + (a_4) * np.pi/180 + (b_2) * np.pi/180
    phaseRe17 = np.cos(phase17)
    phaseIm17 = np.sin(phase17)
    SumRe17 += phaseRe17
    SumIm17 += phaseIm17

for i in range(4, 6):
    phase5 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180 ) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (a_8) * np.pi/180 + (b_4) * np.pi/180 + (c_2) * np.pi/180
    phaseRe5 = np.cos(phase5)
    phaseIm5 = np.sin(phase5)
    SumRe5 += phaseRe5
    SumIm5 += phaseIm5
    
for i in range(6, 8):
    phase18 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (a_8) * np.pi/180 + (b_4) * np.pi/180 + (d_2) * np.pi/180
    phaseRe18 = np.cos(phase18)
    phaseIm18 = np.sin(phase18)
    SumRe18 += phaseRe18
    SumIm18 += phaseIm18
    
for i in range(8, 10):
    phase4 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (b_8) * np.pi/180 + (c_4) * np.pi/180 + (e_2) * np.pi/180
    phaseRe4 = np.cos(phase4)
    phaseIm4 = np.sin(phase4)
    SumRe4 += phaseRe4
    SumIm4 += phaseIm4
    
for i in range(10, 12):
    phase19 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (b_8) * np.pi/180 + (c_4) * np.pi/180 + (f_2) * np.pi/180
    phaseRe19 = np.cos(phase19)
    phaseIm19 = np.sin(phase19)
    SumRe19 += phaseRe19
    SumIm19 += phaseIm19

for i in range(12, 14):
    phase6 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (b_8) * np.pi/180 + (d_4) * np.pi/180 + (g_2) * np.pi/180
    phaseRe6 = np.cos(phase6)
    phaseIm6 = np.sin(phase6)
    SumRe6 += phaseRe6
    SumIm6 += phaseIm6
    
for i in range(14, 16):
    phase20 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (a_16) * np.pi/180 + (b_8) * np.pi/180 + (d_4) * np.pi/180 + (h_2) * np.pi/180
    phaseRe20 = np.cos(phase20)
    phaseIm20 = np.sin(phase20)
    SumRe20 += phaseRe20
    SumIm20 += phaseIm20

for i in range(16, 18):
    phase2 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (c_8) * np.pi/180 + (e_4) * np.pi/180 + (i_2) * np.pi/180
    phaseRe2 = np.cos(phase2)
    phaseIm2 = np.sin(phase2)
    SumRe2 += phaseRe2
    SumIm2 += phaseIm2
    
for i in range(18, 20):
    phase21 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (c_8) * np.pi/180 + (e_4) * np.pi/180 + (j_2) * np.pi/180
    phaseRe21 = np.cos(phase21)
    phaseIm21 = np.sin(phase21)
    SumRe21 += phaseRe21
    SumIm21 += phaseIm21
    
for i in range(20, 22):
    phase7 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (c_8) * np.pi/180 + (f_4) * np.pi/180 + (k_2) * np.pi/180
    phaseRe7 = np.cos(phase7)
    phaseIm7 = np.sin(phase7)
    SumRe7 += phaseRe7
    SumIm7 += phaseIm7
    
for i in range(22, 24):
    phase22 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (c_8) * np.pi/180 + (f_4) * np.pi/180 + (l_2) * np.pi/180
    phaseRe22 = np.cos(phase22)
    phaseIm22 = np.sin(phase22)
    SumRe22 += phaseRe22
    SumIm22 += phaseIm22
    
for i in range(24, 26):
    phase3 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (d_8) * np.pi/180 + (g_4) * np.pi/180 + (m_2) * np.pi/180
    phaseRe3 = np.cos(phase3)
    phaseIm3 = np.sin(phase3)
    SumRe3 += phaseRe3
    SumIm3 += phaseIm3
    
for i in range(26, 28):
    phase23 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (d_8) * np.pi/180 + (g_4) * np.pi/180 + (n_2) * np.pi/180
    phaseRe23 = np.cos(phase23)
    phaseIm23 = np.sin(phase23)
    SumRe23 += phaseRe23
    SumIm23 += phaseIm23
    
for i in range(28, 30):
    phase8 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (d_8) * np.pi/180 + (h_4) * np.pi/180 + (o_2) * np.pi/180
    phaseRe8 = np.cos(phase8)
    phaseIm8 = np.sin(phase8)
    SumRe8 += phaseRe8
    SumIm8 += phaseIm8
    
for i in range(30, 32):
    phase24 = i * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[i] * np.pi/180 + (a_32) * np.pi/180 + (b_16) * np.pi/180 + (d_8) * np.pi/180 + (h_4) * np.pi/180 + (p_2) * np.pi/180
    phaseRe24 = np.cos(phase24)
    phaseIm24 = np.sin(phase24)
    SumRe24 += phaseRe24
    SumIm24 += phaseIm24
    
for l in range (32, 34):
    phase9 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (e_8) * np.pi/180 + (i_4) * np.pi/180 + (q_2) * np.pi/180
    phaseRe9 = np.cos(phase9)
    phaseIm9 = np.sin(phase9)
    SumRe9 += phaseRe9
    SumIm9 += phaseIm9
    
for l in range (34, 36):
    phase25 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (e_8) * np.pi/180 + (i_4) * np.pi/180 + (r_2) * np.pi/180
    phaseRe25 = np.cos(phase25)
    phaseIm25 = np.sin(phase25)
    SumRe25 += phaseRe25
    SumIm25 += phaseIm25
    
for l in range (36, 38):
    phase10 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (e_8) * np.pi/180 + (j_4) * np.pi/180 + (s_2) * np.pi/180    
    phaseRe10 = np.cos(phase10)
    phaseIm10 = np.sin(phase10)
    SumRe10 += phaseRe10
    SumIm10 += phaseIm10
    
for l in range (38, 40):
    phase26 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (e_8) * np.pi/180 + (j_4) * np.pi/180 + (t_2) * np.pi/180   
    phaseRe26 = np.cos(phase26)
    phaseIm26 = np.sin(phase26)
    SumRe26 += phaseRe26
    SumIm26 += phaseIm26

for l in range (40, 42):
    phase11 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (f_8) * np.pi/180 + (k_4) * np.pi/180 + (u_2) * np.pi/180  
    phaseRe11 = np.cos(phase11)
    phaseIm11 = np.sin(phase11)
    SumRe11 += phaseRe11
    SumIm11 += phaseIm11
    
for l in range (42, 44):
    phase27 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (f_8) * np.pi/180 + (k_4) * np.pi/180 + (v_2) * np.pi/180  
    phaseRe27 = np.cos(phase27)
    phaseIm27 = np.sin(phase27)
    SumRe27 += phaseRe27
    SumIm27 += phaseIm27
    
for l in range (44, 46):
    phase12 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (f_8) * np.pi/180 + (l_4) * np.pi/180 + (w_2) * np.pi/180  
    phaseRe12 = np.cos(phase12)
    phaseIm12 = np.sin(phase12)
    SumRe12 += phaseRe12
    SumIm12 += phaseIm12
    
for l in range (46, 48):
    phase28 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (c_16) * np.pi/180 + (f_8) * np.pi/180 + (l_4) * np.pi/180 + (x_2) * np.pi/180  
    phaseRe28 = np.cos(phase28)
    phaseIm28 = np.sin(phase28)
    SumRe28 += phaseRe28
    SumIm28 += phaseIm28
    
for l in range (48, 50):
    phase13 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (g_8) * np.pi/180 + (m_4) * np.pi/180 + (y_2) * np.pi/180
    phaseRe13 = np.cos(phase13)
    phaseIm13 = np.sin(phase13)
    SumRe13 += phaseRe13
    SumIm13 += phaseIm13
    
for l in range (50, 52):
    phase29 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (g_8) * np.pi/180 + (m_4) * np.pi/180 + (z_2) * np.pi/180
    phaseRe29 = np.cos(phase29)
    phaseIm29 = np.sin(phase29)
    SumRe29 += phaseRe29
    SumIm29 += phaseIm29
    
for l in range (52, 54):
    phase14 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (g_8) * np.pi/180 + (n_4) * np.pi/180 + (aa_2) * np.pi/180   
    phaseRe14 = np.cos(phase14)
    phaseIm14 = np.sin(phase14)
    SumRe14 += phaseRe14
    SumIm14 += phaseIm14
    
for l in range (54, 56):
    phase30 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (g_8) * np.pi/180 + (n_4) * np.pi/180 + (ab_2) * np.pi/180   
    phaseRe30 = np.cos(phase30)
    phaseIm30 = np.sin(phase30)
    SumRe30 += phaseRe30
    SumIm30 += phaseIm30
    
for l in range (56, 58):
    phase15 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (h_8) * np.pi/180 + (o_4) * np.pi/180 + (ac_2) * np.pi/180 
    phaseRe15 = np.cos(phase15)
    phaseIm15 = np.sin(phase15)
    SumRe15 += phaseRe15
    SumIm15 += phaseIm15
    
for l in range (58, 60):
    phase31 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (h_8) * np.pi/180 + (o_4) * np.pi/180 + (ad_2) * np.pi/180 
    phaseRe31 = np.cos(phase31)
    phaseIm31 = np.sin(phase31)
    SumRe31 += phaseRe31
    SumIm13 += phaseIm31
    
for l in range (60, 62):
    phase16 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (h_8) * np.pi/180 + (p_4) * np.pi/180 + (ae_2) * np.pi/18   
    phaseRe16 = np.cos(phase16)
    phaseIm16 = np.sin(phase16)
    SumRe16 += phaseRe16
    SumIm16 += phaseIm16
    
for l in range (62, N):
    phase32 =  l * (beta * d * np.sin(p*np.pi/180) + phase_angle * np.pi/180) + phase[l] * np.pi/180 + (b_32) * np.pi/180 + (d_16) * np.pi/180 + (h_8) * np.pi/180 + (p_4) * np.pi/180 + (af_2) * np.pi/18   
    phaseRe32 = np.cos(phase32)
    phaseIm32 = np.sin(phase32)
    SumRe32 += phaseRe32
    SumIm32 += phaseIm32
    
    
#intensity2 = np.sqrt(abs(((SumRe1+SumRe2+SumRe3+SumRe4+SumRe5+SumRe6+SumRe7+SumRe8+SumRe9+SumRe10+SumRe11+SumRe12+SumRe13+SumRe14+SumRe15+SumRe16)/N)**2 + ((SumIm1+SumIm2+SumIm3+SumIm4+SumIm5+SumIm6+SumIm7+SumIm8+SumIm9+SumIm10+SumIm11+SumIm12+SumIm13+SumIm14+SumIm15+SumIm16)/N)**2))
intensity2 = abs(((SumRe1+SumRe2+SumRe3+SumRe4+SumRe5+SumRe6+SumRe7+SumRe8+SumRe9+SumRe10+SumRe11+SumRe12+SumRe13+SumRe14+SumRe15+SumRe16+SumRe17+SumRe18+SumRe19+SumRe20+SumRe21+SumRe22+SumRe23+SumRe24+SumRe25+SumRe26+SumRe27+SumRe28+SumRe29+SumRe30+SumRe31+SumRe32)/N)**2 + ((SumIm1+SumIm2+SumIm3+SumIm4+SumIm5+SumIm6+SumIm7+SumIm8+SumIm9+SumIm10+SumIm11+SumIm12+SumIm13+SumIm14+SumIm15+SumIm16+SumIm17+SumIm18+SumIm19+SumIm20+SumIm21+SumIm22+SumIm23+SumIm24+SumIm25+SumIm26+SumIm27+SumIm28+SumIm29+SumIm30+SumIm31+SumIm32)/N)**2)
print(len(intensity2))
print(intensity2)
max_inten_16_left = 0
max_inten_16_mid = 0
max_inten_16_right = 0
for k in range(0, 4850):
    if intensity2[k] > max_inten_16_left:
        max_inten_16_left = intensity2[k]
        
for l in range(10002):
    if intensity2[l] > max_inten_16_mid:
       max_inten_16_mid = intensity2[l]
      
for m in range(5150, 10002):
    if intensity2[m] > max_inten_16_right:
       max_inten_16_right = intensity2[m]


        
#print(max_inten_16)

PSLL1 = max_inten_16_mid / max_inten_16_left
PSLL2 = max_inten_16_mid / max_inten_16_right

if max_inten_16_left > max_inten_16_right:
    PSLL = 10 * math.log(PSLL1, 10)
else:
    PSLL = 10 * math.log(PSLL2, 10)




print("max_inten_left: ", max_inten_16_left)
print("max_inten_mid: ", max_inten_16_mid)
print("max_inten_right: ", max_inten_16_right)
print("PSLL: ", PSLL)
print("s_2 = ", t_2)
#------------------------------------------------------------------------------


plt.figure(figsize = (12, 8))


plt.ylim([0, 1])    # boundary of y axis
plt.yticks([0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0])  # set y scale
plt.plot(p, intensity2)
plt.title('Phase0 = 0 deg')
plt.xlabel('phase dimension (degree)')

plt.ylabel('intensity')
plt.grid(True)
plt.show()


end = time.process_time()
print("execution time %fsec"%(end - start))

#------------------------------------------------------------------------------
'''
organize the whole compensate phase and output to excel file 
'''
group1_1 = a_32
group1_2 = b_32

group2_1 = a_32 + a_16
group2_2 = a_32 + b_16
group2_3 = b_32 + c_16
group2_4 = b_32 + d_16

group3_1 = a_32 + a_16 + a_8
group3_2 = a_32 + a_16 + b_8
group3_3 = a_32 + b_16 + c_8
group3_4 = a_32 + b_16 + d_8
group3_5 = b_32 + c_16 + e_8
group3_6 = b_32 + c_16 + f_8
group3_7 = b_32 + d_16 + g_8
group3_8 = b_32 + d_16 + h_8

group4_1 =  a_32 + a_16 + a_8 + a_4
group4_2 =  a_32 + a_16 + a_8 + b_4
group4_3 =  a_32 + a_16 + b_8 + c_4
group4_4 =  a_32 + a_16 + b_8 + d_4
group4_5 =  a_32 + b_16 + c_8 + e_4
group4_6 =  a_32 + b_16 + c_8 + f_4
group4_7 =  a_32 + b_16 + d_8 + g_4
group4_8 =  a_32 + b_16 + d_8 + h_4
group4_9 =  b_32 + c_16 + e_8 + i_4
group4_10 =  b_32 + c_16 + e_8 + j_4
group4_11 =  b_32 + c_16 + f_8 + k_4
group4_12 =  b_32 + c_16 + f_8 + l_4
group4_13 =  b_32 + d_16 + g_8 + m_4
group4_14 =  b_32 + d_16 + g_8 + n_4
group4_15 =  b_32 + d_16 + h_8 + o_4
group4_16 =  b_32 + d_16 + h_8 + p_4


group1 = [group1_1, group1_2]
group2 = [group2_1, group2_2, group2_3, group2_4]
group3 = [group3_1, group3_2, group3_3, group3_4, group3_5, group3_6, group3_7, group3_8]
group4 = [group4_1, group4_2, group4_3, group4_4, group4_5, group4_6, group4_7, group4_8, group4_9, group4_10, group4_11, group4_12, group4_13, group4_14, group4_15, group4_16]

import openpyxl
from openpyxl import Workbook
# built an Excel file
excel_file = Workbook()


sheet = excel_file.active

sheet['A1'] = 'Group1'
sheet['B1'] = 'Group2'
sheet['C1'] = 'Group3'
sheet['D1'] = 'Group4'


for i in range(len(group1)):
    columnA = group1[i]
    sheet.append([columnA])

for j in range(len(group2)):
    columnB = group2[j]
    sheet.append([columnB])

for i in range(len(group3)):
    columnC = group3[i]
    sheet.append([columnC])

for j in range(len(group4)):
    columnD = group4[j]
    sheet.append([columnD])
    

        
# save to XLSX file 
excel_file.save('phase_correction.xlsx') 

