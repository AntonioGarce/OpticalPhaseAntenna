# -*- coding: utf-8 -*-
"""
Created on Mon Jun  7 20:17:49 2021

@author: Hsuan

get each point of the far field and ouput to excel file

"""


import numpy as np
import cv2
from PIL import Image
np.set_printoptions(threshold=np.inf)




#------------------------------------------------------------------------------
img = cv2.imread(r"C:/Users/EE810/Desktop/YiHsuan/Device meeting/20210609/aperiodic 64 antenna_5pi.png") 
print(type(img))
print('img.shape =', img.shape)
# start point of x and y axis
x = 45
y = 23

# width and height
w = 1004
h = 652

# cut the picture
crop_img = img[y:y+h, x:x+w]

#cv2.imshow("cropped", crop_img)
cv2.waitKey(0)

cv2.imwrite('crop.jpg', crop_img)

#------------------------------------------------------------------------------
im = Image.open(##the path of the file##)
#im.show()

im_array = np.array(im)

#L =im.convert('L')
#L.show()
w,h = im.size
print('crop_img:','w =',w,'h =',h)

blackwhiteImg = im.convert('L')

blackwhiteImg.save('blackwhiteImg .jpg')
#blackwhiteImg.show()

#print(L.size)

threshold = 160

lut= []

for i in range(256): ## range：0-255

    if i < threshold:
        lut.append(0)
    else :
        lut.append(255)


binaryImg = blackwhiteImg.point(lut, 'L') ## turn to binary image
#binaryImg.show()
binaryImg.save("binary.jpg")



pixels = [ (x,y) for x in range(w) for y in range(h) ] ##get each point of pixel

pixelVal = [] ##the value of each pixel

for point in pixels:

    value = binaryImg.getpixel(point)
    pixelVal.append(value)

biArray = np.array(pixelVal).reshape(w,-1)

print('biArray_type =',type(biArray))




#------------------------------------------------------------------------------
listA = biArray.tolist()
print ('listA_type =',type(listA))
print('list_len =', len(listA))

import openpyxl
from openpyxl import Workbook
# built an Excel file
excel_file = Workbook()


sheet = excel_file.active

sheet['A1'] = 'row'
sheet['B1'] = 'Normalize'



for l in range(0, w):
    for m in range(0, h):
        if listA[l][m] != 0:
            m = m+1
        else:
            #print(l+1,m+1)
            #print (m)
            normal = (h -m+1)/h
            
            columnA = str(l+1)   
            columnB = str('%.3f' %normal)
            columnC = str(m)
            sheet.append([columnA, columnB, columnC])
            
            f = open('C:/Users/EE810/Desktop/normalize.txt','a')
            print('row',l+1, 'No.', m+1, 'normalize =','%.3f' %normal, file = f)
            f.close()
            break
    
 
# save to XLSX file
excel_file.save('Normalize.xlsx')
