import numpy as np
import pygad2
import FFP_processing_pygad
from scipy.signal import find_peaks
import matplotlib.pyplot

print("STEERING 0")
N = 64
step = 0.01 #data point

#define target of PSLL
target = 0.0

#Defining the angle range
theta = np.arange(-4.5, 4.5, step) #plotting angle
theta1 = np.arange(-19, 19,step) #beam steering plot


angle_left_SL = np.arange(-4.5, -0.13, step)
angle = np.arange(-0.12, 0.13, step)
angle_right_SL = np.arange(0.12, 4.5, step)

'''angle_left_SL = np.arange(-4.5, -4.17, step)
angle = np.arange(-4.18, -3.81, step)
angle_right_SL = np.arange(-3.82, 4.5, step)'''

#INITIAL 
pop_size = (1, N)
init_pop = np.random.uniform(low=-2*np.pi, high=2*np.pi, size=pop_size)

sol_per_pop=10
#solution = pygad.GA.initialize_population(self, low=-2*np.pi, high=2*np.pi)


def fitness_func(solution, solution_index):
    #print ("solution", solution)
    #side-lobe and main lobe calculation
    ILSL = FFP_processing_pygad.left_SL(solution, angle_left_SL)
    IRSL = FFP_processing_pygad.right_SL(solution, angle_right_SL)
    IML = FFP_processing_pygad.ML(solution, angle)

    ILSL_trans = np.transpose(ILSL)
    IRSL_trans = np.transpose(IRSL)
    IML_trans = np.transpose(IML)   

    #PEAK DETECTION (searching the highest intensity of sidelobe and mainlobe)
    max_ILSL = max(ILSL_trans)
    max_IRSL = max(IRSL_trans)
    max_IML = max(IML_trans)

    #peaks_L, _ = find_peaks(ILSL_trans, height=0)
    #peaks_R, _ = find_peaks(IRSL_trans, height=0)
    #peaks_M, _ = find_peaks(IML_trans, height=0)

    #max_ILSL = max(ILSL_trans[peaks_L])
    #max_IRSL = max(IRSL_trans[peaks_R])
    #max_IML = max(IML_trans[peaks_M])

    #PSLL Cal
    high_sidelobe = max(max_ILSL, max_IRSL)
    PSLL = high_sidelobe / max_IML

    #Fitnes Calculation
    fitness = 1/(np.abs(PSLL - target) + 1)
    return fitness

'''def callback_generation(ga_instance):
    print("Generation : ", ga_instance.generations_completed)
    #print("Fitness of the best solution :", ga_instance.best_solution()[1])
    if ga_instance.best_solution()[1] >= 0.952:
        return "stop" '''

ga_instance = pygad2.GA(num_generations=1000, 
                        fitness_func=fitness_func,
                        num_parents_mating=6,
                        sol_per_pop=10,
                        num_genes=N,
                        init_range_high= 1.885*np.pi,  #1.885
                        init_range_low= -1.845*np.pi, #-1.845
                        crossover_type="uniform",
                        mutation_type="adaptive",
                        mutation_probability=[0.37, 0.22]) # 0 deg: [0.35, 0.05]; >2 deg: [0.45, 0.15]
                        #on_generation=callback_generation)


ga_instance.run()

# Returning the details of the best solution.
solution, solution_fitness, solution_idx = ga_instance.best_solution()
print("SOLUTION:", solution)
print("FITNESS:", solution_fitness)
print("PSLL:", np.abs(((1-solution_fitness)/solution_fitness)+target))
#print("Parameters of the best solution : {solution}".format(solution=solution))
#print("Fitness value of the best solution = {solution_fitness}".format(solution_fitness=solution_fitness))
#print("Index of the best solution : {solution_idx}".format(solution_idx=solution_idx))



#INTENSITY FOR PLOTTING AND BEAM STEERING
intens = FFP_processing_pygad.FFP_plot(solution, theta)
intens_trans = np.transpose(intens) #solution

intensrand = FFP_processing_pygad.FFP_randplot(init_pop, theta)
intensrand_trans = np.transpose(intensrand) #initial condition

np.savetxt("phase of BS 0.csv", solution, delimiter=",")

#PLOTTING SECTION
matplotlib.pyplot.subplot(211)
matplotlib.pyplot.title('Optimized FFP')
matplotlib.pyplot.plot(theta, intensrand_trans, 'blue', label="Initial FFP")
matplotlib.pyplot.plot(theta, intens_trans, 'green', label='Optimized FFP')
matplotlib.pyplot.xlabel('ψ (degree)')
matplotlib.pyplot.ylabel('Intensity (a.u)')
matplotlib.pyplot.grid()
matplotlib.pyplot.legend()

matplotlib.pyplot.subplot(212)
matplotlib.pyplot.title('Optimized Phase Distribution')
matplotlib.pyplot.plot(init_pop.ravel()/np.pi, 'rx', label='Initial Phase')
matplotlib.pyplot.plot(solution/np.pi, 'ko', label='Optimized Phase')
matplotlib.pyplot.xlabel("N-elements")
matplotlib.pyplot.ylabel("Phase (Pi)")
matplotlib.pyplot.grid()
matplotlib.pyplot.legend()


matplotlib.pyplot.tight_layout()

ga_instance.plot_result(title="Fitness", linewidth=2)