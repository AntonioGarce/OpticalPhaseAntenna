import numpy as np
import random

N = 64
a = 1.83
d = 9.5
lambda_ = 1.55
k = 2*np.pi/lambda_

'''error = np.array([ 1.74393951,  1.69298425,  7.81665919,  7.78993883,  1.38637602,  1.19794832,
  0.74130252, -6.15912131, -6.42749134, -7.01748103, -1.130338,   -1.28785382,
 -1.33106344, -8.11470013, -1.84558601,  4.45454598,  4.24663155, 10.27983055,
 -2.33729483, -2.43066302,  3.57235081, -2.86820789,  3.35413183,  3.14562084,
  2.84778997, -3.58540719,  2.61764995, -3.73314589,  2.51995602, -3.8907074,
  2.26119161,  2.28232772, -3.91138384,  2.26092743, -3.89472713, -3.69370957,
 -3.53758997, -3.43973605, -3.31945408, -3.3721934,  -3.5284849,   2.9952291,
 -3.16496618, -3.13558323, -3.27905925,  9.67148521,  3.67930203, -2.71439836,
  3.51459521,  3.90286774,  4.17093284,  4.42701847, -1.85488359, -1.57958985,
 -1.40284055,  4.87665195, -1.37716528, -1.34115307, -1.04689409, -1.08504138,
 -1.11971314, -7.41581344,  5.20893784, -1.19547687])'''


'''
#TESTING
def test (pop, angle_left_SL, num_weights):
    sudut = []
    del_Re = []
    del_Im = []
    Intens_left_SL = []
    for ang in range (len(angle_left_SL)):
        for i in range (0, num_weights):
            delta = i + angle_left_SL[ang]
            delta_Re = (delta + pop[(0,1,2,3), i])
            delta_Im = np.sin(delta + pop[(0,1,2,3), i])
            del_Re.append(delta_Re)
            del_Im.append(delta_Im)
        sudut.append(angle_left_SL[ang])
        sum_delta_Re = np.sum(del_Re, axis=0)

    return del_Re
    '''


def left_SL(pop, angle_left_SL):
    Intens_left_SL = []
    for index, angle_L in enumerate(angle_left_SL):
        del_Re_L = []
        del_Im_L = []
        for i in range (0, N):
            #delta_L = (i * k * d * np.sin(np.deg2rad(angle_L)))
            delta_L = (i * k * d * (np.sin(np.deg2rad(angle_L))-np.sin(np.deg2rad(0))) )
            #delta_Re_L = np.cos(delta_L+ error[i] + pop[i]) # [chromosomes, genes]
            #delta_Im_L = np.sin(delta_L+ error[i] + pop[i])
            delta_Re_L = np.cos(delta_L+ pop[i]) # [chromosomes, genes]
            delta_Im_L = np.sin(delta_L+ pop[i])
            del_Re_L.append(delta_Re_L)
            del_Im_L.append(delta_Im_L)

        sum_delta_Re_L = np.sum(del_Re_L, axis=0)
        sum_delta_Im_L = np.sum(del_Im_L, axis=0)

        AF_left_SL = np.abs(sum_delta_Re_L/N + (1j*sum_delta_Im_L/N))
        AB_left_SL = ((np.pi*a)/lambda_)*(np.sin(np.deg2rad(angle_L)))
        Intens_left_SL_ = (((np.sin(AB_left_SL)) / (AB_left_SL))**2) * (AF_left_SL**2)
        Intens_left_SL.append(Intens_left_SL_)

    return Intens_left_SL
   
def right_SL(pop, angle_right_SL):
    Intens_right_SL = []    
    for index, angle_R in enumerate(angle_right_SL):
        del_Re_R = []
        del_Im_R = []
        for i in range (0, N):
            #delta_R = (i * k * d * np.sin(np.deg2rad(angle_R)))
            delta_R = (i * k * d * (np.sin(np.deg2rad(angle_R))-np.sin(np.deg2rad(0))) )
            #delta_Re_R = np.cos(delta_R + error[i] + pop[i])
            #delta_Im_R = np.sin(delta_R + error[i] + pop[i])
            delta_Re_R = np.cos(delta_R + pop[i])
            delta_Im_R = np.sin(delta_R + pop[i])
            del_Re_R.append(delta_Re_R)
            del_Im_R.append(delta_Im_R)

        sum_delta_Re_R = np.sum(del_Re_R, axis=0)
        sum_delta_Im_R = 1j*(np.sum(del_Im_R, axis=0))

        AF_right_SL = np.abs(sum_delta_Re_R/N + (1j*sum_delta_Im_R)/N)
        AB_right_SL = ((np.pi*a)/lambda_)*(np.sin(np.deg2rad(angle_R)))
        Intens_right_SL_ = (((np.sin(AB_right_SL)) / (AB_right_SL))**2) * (AF_right_SL**2)
        Intens_right_SL.append(Intens_right_SL_)

    return Intens_right_SL

def ML(pop,angle):
    Intens_ML = []
    for index, angle_M in enumerate(angle):
        del_Re = []
        del_Im = []
        for i in range (0, N):
            #delta = (i * k * d * np.sin(np.deg2rad(angle_M)))
            delta = (i * k * d * (np.sin(np.deg2rad(angle_M))-np.sin(np.deg2rad(0))) )
            #delta_Re = np.cos(delta + error[i] + pop[i])
            #delta_Im = np.sin(delta + error[i] + pop[i])
            delta_Re = np.cos(delta + pop[i])
            delta_Im = np.sin(delta + pop[i])
            del_Re.append(delta_Re)
            del_Im.append(delta_Im)

        sum_delta_Re = np.sum(del_Re, axis=0)
        sum_delta_Im = np.sum(del_Im, axis=0)

        AF_ML = np.abs(sum_delta_Re/N + (1j*sum_delta_Im/N))
        AB_ML = ((np.pi*a)/lambda_)*(np.sin(np.deg2rad(angle_M)))
        Intens_ML_ = (((np.sin(AB_ML)) / (AB_ML))**2) * (AF_ML**2)
        Intens_ML.append(Intens_ML_)

    return Intens_ML

def FFP_plot (best_pop, theta):
    intens_plot = []
    for index, ang in enumerate(theta):
        de_Re = []
        de_Im = []
        for i in range (0, N):
            delta = (i * k * d * np.sin(np.deg2rad(ang)))
            #del_Re = np.cos(delta + error[i] + best_pop[i])
            #del_Im = np.sin(delta + error[i] + best_pop[i])
            del_Re = np.cos(delta + best_pop[i])
            del_Im = np.sin(delta + best_pop[i])
            de_Re.append(del_Re)
            de_Im.append(del_Im)

        sum_del_Re = np.sum(de_Re, axis=0)
        sum_del_Im = np.sum(de_Im, axis=0)

        AF = np.abs(sum_del_Re/N + (1j*sum_del_Im/N))
        AB = ((np.pi*a)/lambda_)*(np.sin(np.deg2rad(ang)))
        Intens = (((np.sin(AB)) / (AB))**2) * (AF**2)
        intens_plot.append(Intens)
    return intens_plot

def FFP_randplot (solution, theta):
    intens_plot = []
    for index, ang in enumerate(theta):
        de_Re = []
        de_Im = []
        for i in range (0, N):
            delta = (i * k * d * np.sin(np.deg2rad(ang)))
            del_Re = np.cos(delta + solution[0,i])
            del_Im = np.sin(delta + solution[0,i])
            #del_Re = np.cos(delta + error[i] + solution[0,i])
            #del_Im = np.sin(delta + error[i] + solution[0,i])
            de_Re.append(del_Re)
            de_Im.append(del_Im)

        sum_del_Re = np.sum(de_Re, axis=0)
        sum_del_Im = np.sum(de_Im, axis=0)

        AF = np.abs(sum_del_Re/N + (1j*sum_del_Im/N))
        AB = ((np.pi*a)/lambda_)*(np.sin(np.deg2rad(ang)))
        Intens = (((np.sin(AB)) / (AB))**2) * (AF**2)
        intens_plot.append(Intens)
    return intens_plot

def FFP_plot1 (best_pop, theta, deg):
    intens_plot = []
    for index, ang in enumerate(theta):
        de_Re = []
        de_Im = []
        for i in range (0, N):
            delta = (i * k * d * (np.sin(np.deg2rad(ang))-np.sin(np.deg2rad(deg))) )
            del_Re = np.cos(delta + best_pop[i])
            del_Im = np.sin(delta + best_pop[i])
            de_Re.append(del_Re)
            de_Im.append(del_Im)

        sum_del_Re = np.sum(de_Re, axis=0)
        sum_del_Im = np.sum(de_Im, axis=0)

        AF = np.abs(sum_del_Re/N + (1j*sum_del_Im/N))
        AB = ((np.pi*a)/lambda_)*(np.sin(np.deg2rad(ang)))
        Intens = (((np.sin(AB)) / (AB))**2) * (AF**2)
        intens_plot.append(Intens)
    return intens_plot

def FFP_plot2 (best_pop, theta):
    intens_plot = []
    for index, ang in enumerate(theta):
        de_Re = []
        de_Im = []
        for i in range (0, N):
            delta = (i * k * d * (np.sin(np.deg2rad(ang))-np.sin(np.deg2rad(2.0))) )
            del_Re = np.cos(delta + best_pop[i])
            del_Im = np.sin(delta + best_pop[i])
            de_Re.append(del_Re)
            de_Im.append(del_Im)

        sum_del_Re = np.sum(de_Re, axis=0)
        sum_del_Im = np.sum(de_Im, axis=0)

        AF = np.abs(sum_del_Re/N + (1j*sum_del_Im/N))
        AB = ((np.pi*a)/lambda_)*(np.sin(np.deg2rad(ang)))
        Intens = (((np.sin(AB)) / (AB))**2) * (AF**2)
        intens_plot.append(Intens)
    return intens_plot

def peak_detection_left (ILSL_trans, sol_per_pop):
    max_ILSL_ = max(ILSL_trans)
    max_ILSL.append(max_ILSL_)
    return max_ILSL

def peak_detection_right (IRSL_trans, sol_per_pop):
    max_IRSL = []
    for i in range (sol_per_pop):
        max_IRSL_ = max(IRSL_trans[i])
        max_IRSL.append(max_IRSL_)
    return max_IRSL

def peak_detection_center (IML_trans, sol_per_pop):
    max_IML = []
    for i in range (sol_per_pop):
        max_IML_ = max(IML_trans[i])
        max_IML.append(max_IML_)
    return max_IML

def cal_PSLL (max_LSLI, max_MLI, max_RSLI):
    PSLL = []
    for i in range (0, 10):
        high = max(max_LSLI[i], max_RSLI[i])
        PSLL_ = high/max_MLI[i]
        PSLL.append(PSLL_)
    return PSLL


